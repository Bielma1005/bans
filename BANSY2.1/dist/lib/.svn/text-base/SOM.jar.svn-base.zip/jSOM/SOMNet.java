/*
 * SOMNet.java
 *
 * Created on 12 de febrero de 2007, 14:51
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jSOM;

/**
 *
 * @author jjimenez
 */
public class SOMNet {
    
    private double Nc = 1;
		/// <summary>
		/// minimo promedio UMatrix
		/// </summary>
		public double minUM;
		/// <summary>
		/// maximo promedio umatrix
		/// </summary>
		public double maxUM;

    public double minComp;
    public double maxComp;

    public double maxQE;
		/// <summary>
		/// arreglo de neuronas
		/// </summary>
		public int maxFrec;
		/// <summary>
		/// Conjunto de neuronas asociadas a la red neuronal
		/// </summary>
		public SOMNeuron[][] neurons=null;
		public double[][] X=null;
		/// <summary>
		/// numero de neuronas de entrada
		/// </summary>
		public int ne;
		/// <summary>
		/// Numero de neuronas de salida
		/// </summary>
		public int ns;
		/// <summary>
		/// Numero de veces que se han presentado los ejemplos
		/// </summary>
		public long iterAllSamples;
		/// <summary>
		/// Total de iteraciones a realiza
		/// </summary>
		public long iter;
		/// <summary>
		/// Determina la manera qe decae Sigma
		/// cero para que decaiga de una manera continua
		/// uno para que permanesca constante un tiempo y despues decaiga de manera continua
		/// </summary>
		public int sigmaMo=0;
		/// <summary>
		/// Si se trata de datos de descritores o de puntos
		/// </summary>
		private boolean Data=false;
		
		/// <summary>
		/// 
		/// </summary>
		public int iterOneSample=0;

		public SOMParameters somParameters=new SOMParameters();
      
    /** Creates a new instance of SOMNet */
    public SOMNet() {
        
    }
    
    
    	public SOMNet(int numNE,int numNS)
		{
			//
			// TODO: Add constructor logic here
			//
			//inicializa el arrglo de neuronas
			ne=numNE;
			ns=numNS;
			neurons=new SOMNeuron[numNS][];
			//inicializa cada neurona
			for (int i=0;i<numNS;i++)
			{
				neurons[i]=new SOMNeuron[numNS];
				for (int j=0;j<numNS;j++)
				{
					neurons[i][j]=new SOMNeuron(numNE,i,j);
				}
			}
		}
      
      
      	/// <summary>
		/// Calcula las activaciones de todas las neuronas
		/// y devuelve la ganadora
		/// </summary>
		/// <param name="x">El dato</param>
		/// <returns>La neurona ganadora</returns>
		public SOMNeuron getWinner(double[] x)
		{
			double temp=neurons[0][0].getActiva(x);
			SOMNeuron win=neurons[0][0];
			for (int i=0;i<ns;i++)
			{
				for (int j=0;j<ns;j++)
				{
					if(neurons[i][j].getActiva(x)<temp)
					{
						win=neurons[i][j];
						temp=neurons[i][j].activacion;
					}
				}
			}
			return win;
		}
      
      public void actualizaW(SOMNeuron win,double[] x, int t)
		{
			double alfa=somParameters.getLearningF(t);
			double sigma=somParameters.getSigma(t,iterAllSamples,ns);
			for (int i=0;i<ns;i++)
			{
				for (int j=0;j<ns;j++)
				{
					//Gaussiana
					if(win!=null && neurons[i][j]!=null)
					{
						double dif=getDiference(win,neurons[i][j]);
                   Nc=Math.exp(-(dif)/(2*Math.pow(sigma,2.0)));
						double h = alfa*Nc;
						neurons[i][j].actualizaWCohonen(x,h,win);
               }            
					else
						System.out.println("Error: Winner null or neuron["+i+"]["+j+"] null");
				}
			}
		}
      
      private double getDiference(SOMNeuron win, SOMNeuron other)
		{
		
      //No se le saca la raiz cuadrada porqe en el calculo de lo gausina no se eleva al cuadrado
        double dif=Math.pow((win.ia-other.ia),2)+Math.pow((win.ja-other.ja),2);			
			return dif;
		}
    
     public void reSetVoronios()
    {
      for (int i = 0; i < ns; i++)
      {
        for (int j = 0; j < ns; j++)
        {
          neurons[i][j].reSetVoronio();
        }
      }
    }
}
