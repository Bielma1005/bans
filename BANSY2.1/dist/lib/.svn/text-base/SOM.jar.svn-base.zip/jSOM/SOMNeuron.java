/*
 * SOMNeuron.java
 *
 * Created on 12 de febrero de 2007, 14:40
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jSOM;

import java.util.Vector;

/**
 *
 * @author jjimenez
 */
public class SOMNeuron {
    
		public double[] w=null;
      
		public double w_magnitud=0;		
		public String name="Noname";
		
		public double activacion=0;
		/// <summary>
		/// renglon en el arregle de neuronas
		/// </summary>
		public int ia;
		/// <summary>
		/// columna en el que se encuantra la neurona
		/// </summary>
		public int ja;
		/// <summary>
		/// coordenada en z
		/// </summary>		
		public int ka;
		/// <summary>
		/// si los pesos se inicializaron aleatoriamente
		/// </summary>
		public boolean isRandom=false;

		public double promUM;
		
		/// <summary>
		/// Conjunto de Voronoi
		/// </summary>
		public Vector Asociatedfeatures=new Vector();

    public Vector AsociatedfeaturesActivations = new Vector();

    public double qError;
    
    /** Creates a new instance of SOMNeuron */
    public SOMNeuron(int numEn, int i_, int j_) {
        w=new double[numEn];
			
			name=""+i_+""+j_;
         
			ia=i_;
			ja=j_;
    }
    
     /** Creates a new instance of SOMNeuron */
    public SOMNeuron(int numEn, int i_, int j_, int k_) {
        w=new double[numEn];
			
			name=""+i_+""+j_;

			ia=i_;
			ja=j_;
         ka=k_;
    }
    
    	public void initializeW()
		{		
			
			for(int i=0;i<w.length;i++)
				w[i]=0;
		}
      
      public double getActiva(double[] x)
		{
			double act=0;
			for (int i=0;i<x.length;i++)
			{
				act+=Math.pow((x[i]-w[i]),2);
			}
			act=Math.sqrt(act);
			activacion=act;
			return act;
		}
      
      public double getDistancia(SOMNeuron n)
		{
			double d=0;
			for (int i=0;i<w.length;i++)
			{
				d+=Math.pow((w[i]-n.w[i]),2);
			}
			d=Math.sqrt(d);
			return d;
		}
      
    public void reSetVoronio()
    {
      this.Asociatedfeatures.clear();
      this.AsociatedfeaturesActivations.clear();
    }
    
    
    	public void actualizaWCohonen(double[] x, double h,SOMNeuron win)
		{
			for(int i=0;i<x.length;i++)
			{
				w[i]=w[i]+h*(x[i]-w[i]);
			}
		}

    
}
