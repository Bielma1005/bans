/*
 * SOMTrainer.java
 *
 * Created on 12 de febrero de 2007, 15:34
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jSOM;

/**
 *
 * @author jjimenez
 */
public class SOMTrainer {
    
    public double[][] X = null;

    private int t_step = 0;

    private int i_step = 0;
    /// <summary>
    /// Vartiable global para saber si se presentan todos los ejemplos o no antes de dibujar la red
    /// durenate el entrenamiento
    /// </summary>
    public boolean allSamples = false;   
    
    public boolean preparedToTraining = false;

    private SOMNet net = null;    
    
    /** Creates a new instance of SOMTrainer */
    public SOMTrainer() {
    }
    
    /** Creates a new instance of SOMTrainer */
    public SOMTrainer(SOMNet net_, double[][] data) {
        net=net_;
        X=data;
    }    
    
    public void preparTraning(int iter)
    {            
      net.iterAllSamples = 0;
      preparedToTraining = true;
      net.iter = iter;
    }
    
    public void trainNext(int t, int i)
    {
      SOMNeuron win_ = net.getWinner(X[i]);
      //Asociar el ejemplo a la neurona ganadora
      win_.Asociatedfeatures.add(i);
      win_.AsociatedfeaturesActivations.add(win_.activacion);
      SOMNeuron win = new SOMNeuron(win_.w.length, win_.ia, win_.ja);
      for (int k = 0; k < win.w.length; k++)
        win.w[k] = win_.w[k];
      win.getActiva(X[i]);
      net.actualizaW(win, X[i], t);
    }
    
    public void stepAllSamples(int t)
    {
      int con = 0;
      for (int i = i_step; i < X.length; i++)
      {
        trainNext(t, i);
        t++;
        net.iterOneSample = t;
      }   
      net.iterAllSamples++;
    }
   
    

    /// <summary>
    /// Entrena la red
    /// </summary>
    /// <param name="iter">Numero de iteraciones a realizar</param>
    /// <param name="X">Ejemplos de entrenamiento</param>
    public void train()
    {      
      for (int t = t_step; t < net.iter; t += X.length)
      {
        net.reSetVoronios();
        stepAllSamples(t);        
      }   
    }
    
}
