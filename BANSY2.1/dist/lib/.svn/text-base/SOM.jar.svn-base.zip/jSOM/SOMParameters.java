/*
 * SOMParameters.java
 *
 * Created on 12 de febrero de 2007, 14:50
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package jSOM;

/**
 *
 * @author jjimenez
 */
public class SOMParameters {
    
    /// <summary>
		/// Valor maximo para alfa
		/// </summary>
		public double alfaMaxValue=0.9;
		/// <summary>
		/// Tiempo en el que alfa deja de ser constante y se vuelve descendente
		/// </summary>
		public int alfaTimeToChange=10;
		/// <summary>
		/// Valor del factor con el que decrece Alfa
		/// </summary>
		public double alfaValueToChange=0.02;
		/// <summary>
		/// Si es o no Continua Alfa
		/// </summary>
		public boolean alfaContinious=false;


		/// <summary>
		/// Si es o no Continua sigma
		/// </summary>
		public boolean sigmaContinious=false;
		/// <summary>
		/// Tiempo en el que sigma deja de ser constante y se vuelve descendente
		/// </summary>
		public int sigmaTimeToChange=10;
		/// <summary>
		/// divisor del radio
		/// </summary>
		public double initialRadius = 2.0;
    public double radiusAfterChange = 2.0;
		

    public boolean allowSigmaMinorToOne = false;

		/// <summary>
		/// Numero de iteraciones. Se tiene que poner le numero maximo de iteraciones
		/// en el el prececo
		/// </summary>
		public long MaxIter=500;
		/// <summary>
		/// Variable en el que se guarda el numero de la funcion seleccionada
		/// </summary>
		public int selectedFunction=0;
      
      
    /** Creates a new instance of SOMParameters */
    public SOMParameters() {
        
    }
    
    
    public double getLearningF(int t)
		{
			if(alfaContinious)
			return alfaMaxValue*(1-((double)t)/((double)MaxIter));
			else
			{
        if (t < alfaTimeToChange)
        {          
          return alfaMaxValue * (1 - ((double)t) / ((double)alfaTimeToChange));
        }
        else
        {
          
          return alfaValueToChange;
        }
			}
		}	
		

			
		/// <summary>
		/// Devuelve el el radio de la vecindad actual
		/// Sigma depende del tiempo
		/// </summary>
		/// <param name="t">El tiempo actual</param>
		/// <param name="mode">Si se hace decrece de manera continua o no</param>
		/// <returns>El valor de Sigma</returns>
		public double getSigma(int t,long iterOfAllSamples, double ns)
		{
			double result=1;
			if(sigmaContinious)
			{
        result = (ns / (initialRadius)) * (1 - ((double)t) / (((double)MaxIter)));
				if(result<1 && !allowSigmaMinorToOne)
				  result=1;
			}
			else
			{
				if(t<sigmaTimeToChange)
					result = (ns)/initialRadius;
				else
				{					
          
          //Hacer decreser a sigma linealmente a uno
          result = (ns/(radiusAfterChange))*(1 - ((double)t)/(((double)MaxIter)));
          if (result < 1 && !allowSigmaMinorToOne)
					{
						result=1;
					}
				}
			}
			return result;
		}
    
}
